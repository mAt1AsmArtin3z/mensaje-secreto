function revertirTexto(texto){
	return texto.split('').reverse().join('');
}

function invertir(texto){
	let indiceInicio = texto.indexOf("(");
 	let indiceFinal = texto.lastIndexOf(")");

	while (indiceInicio !== -1 && indiceFinal !== -1) {
		let textoDentro = texto.slice(indiceInicio + 1, indiceFinal);
		let textoDentroReverso = revertirTexto(textoDentro);
		texto = texto.slice(0, indiceInicio + 1) + textoDentroReverso + texto.slice(indiceFinal);

		indiceInicio = texto.indexOf("(", indiceInicio + 1);
		indiceFinal = texto.lastIndexOf(")");
	}

	return texto;
}

function myFunction() {
	let texto = document.getElementById("texto").value;
	let textoInvertido = invertir(texto);
	alert(textoInvertido);
}




function revertirTexto(texto) {
    return texto.split('').reverse().join('');
}

function invertir(texto) {
    let resultado = '';
    let dentroParentesis = false;
    let textoDentroParentesis = '';

    for (let i = 0; i < texto.length; i++) {
        if (texto[i] == '(') {
            dentroParentesis = true;
            textoDentroParentesis = '';
        } else if (texto[i] == ')') {
            dentroParentesis = false;
            resultado += '(' + revertirTexto(textoDentroParentesis) + ')';
            textoDentroParentesis = '';
        } else {
            if (dentroParentesis) {
                textoDentroParentesis += texto[i];
            } else {
                resultado += texto[i];
            }
        }
    }

    return resultado;
}

function myFunction() {
    let texto = document.getElementById("texto").value;
    let textoInvertido = invertir(texto);
    alert(textoInvertido);
}


